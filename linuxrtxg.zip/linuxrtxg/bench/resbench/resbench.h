#ifndef __RESBENCH_H__
#define __RESBENCH_H__

typedef unsigned long ulong_t;

#define TRUE 		1
#define FALSE		0 	

#define MAX_BUF 256

#define RET_SUCCESS 1
#define RET_MISS	0

#endif
