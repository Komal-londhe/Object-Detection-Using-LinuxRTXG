# check_ComputeCapability
simple program to check sm_ number of NVIDIA GPU in your machine

##  how to install 
just run `$ make` in the directory 

## how to use 
just run executable file in the directory 
