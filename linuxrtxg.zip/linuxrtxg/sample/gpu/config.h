#ifndef __RTGPU_CONFIG_H__
#define __RTGPU_CONFIG_H__

#define DISABLE_SCHED_CPU
//#define DISABLE_SCHED_GPU
//#define DETAIL_TIME
//#define MUTEX_OFF

#define DEFAULT_PRIO 80
#define LOOP_COUNT 10

#endif
