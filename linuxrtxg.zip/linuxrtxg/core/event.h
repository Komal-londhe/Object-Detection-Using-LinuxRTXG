#ifndef __RESCH_EVENT_H__
#define __RESCH_EVENT_H__

int api_sleep(int, unsigned long);
int api_suspend(int);
int api_wake_up(int);

#endif
