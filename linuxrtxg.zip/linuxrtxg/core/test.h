#ifndef __RESCH_TEST_H__
#define __RESCH_TEST_H__

int test_get_release_cost(int);
int test_get_migration_cost(int);
int test_get_runtime(void);
int test_get_utime(void);
int test_get_stime(void);

#endif
