#ifndef __RESCH_MAIN_H__
#define __RESCH_MAIN_H__

MODULE_LICENSE("Dual BSD/GPL");
MODULE_DESCRIPTION("RESCH");
MODULE_AUTHOR("Shinpei Kato");

#define MODULE_NAME	"resch"

#endif
